Jayware is temporarily unavaiable due to legal issues . . .
